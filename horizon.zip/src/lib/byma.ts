export type BymaCaucionRow = {
    denominationCcy?: string
    daysToMaturity?: number
    maturityDate?: string
    settlementPrice?: number // tasa (TNA) según lo que venís usando
    tradedQty?: number
  }
  
  export type BestByDays = Record<number, BymaCaucionRow>
  
  export async function fetchCauciones() {
    const r = await fetch("/api/cauciones", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ excludeZeroPxAndQty: true }),
    })
    if (!r.ok) throw new Error(`BYMA error: ${r.status}`)
    return r.json()
  }
  
  
  export function bestOffersByDays(rows: BymaCaucionRow[], ccy: "ARS" | "USD" = "ARS"): BestByDays {
    const filtered = rows.filter((x) => x.denominationCcy === ccy)
    const best: BestByDays = {}
  
    for (const x of filtered) {
      const d = Number(x.daysToMaturity)
      if (!Number.isFinite(d) || d < 1 || d > 30) continue
      const rate = Number(x.settlementPrice ?? 0)
      if (!best[d] || rate > Number(best[d].settlementPrice ?? 0)) best[d] = x
    }
    return best
  }
  