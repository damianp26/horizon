export type LecapMetrics = {
    price: number
    priceWithFee: number
    vt: number
    gainPct: number
    tna360: number
    tem: number
  }
  
  export function calcLecapMetrics(args: {
    priceVN100: number          // e.g. 118.15
    vtVN100: number             // e.g. 119.06
    days: number                // e.g. 10
    brokerFeePct: number        // e.g. 0.15
  }): LecapMetrics {
    const { priceVN100, vtVN100, days, brokerFeePct } = args
  
    const priceWithFee = priceVN100 * (1 + brokerFeePct / 100)
    const gainPct = (vtVN100 - priceWithFee) / priceWithFee
  
    const tna360 = gainPct * (360 / Math.max(1, days))
    const tem = Math.pow(1 + gainPct, 30 / Math.max(1, days)) - 1
  
    return {
      price: priceVN100,
      priceWithFee,
      vt: vtVN100,
      gainPct,
      tna360,
      tem,
    }
  }
  

  // src/lib/lecaps.ts
export type LecapsPricesMap = Record<string, { price: number; change: number }>

export async function fetchLecapsPrices(): Promise<LecapsPricesMap> {
  const r = await fetch("/api/lecaps", { method: "GET" })
  if (!r.ok) throw new Error(`LECAPs error: ${r.status}`)
  return r.json()
}
