export type BymaLebacRow = {
    symbol: string
    settlementPrice?: number
    bidPrice?: number
    offerPrice?: number
    maturityDate?: string // YYYY-MM-DD
    daysToMaturity?: number
    denominationCcy?: string
    securitySubType?: string
    market?: string
  }
  
  export async function fetchLebacs(): Promise<BymaLebacRow[]> {
    const r = await fetch("/api/lebacs", { method: "GET" })
    if (!r.ok) throw new Error(`LEBACS error: ${r.status}`)
    const data = await r.json()
    if (!Array.isArray(data)) throw new Error("LEBACS: invalid payload")
    return data
  }
  