// src/lib/lecaps-table.ts
export type LecapsTableItem = Record<string, string> & { _ticker: string }

export type LecapsTableResponse = {
  fetchedAt: string
  source: string
  headers: string[]
  items: LecapsTableItem[]
}

export async function fetchLecapsTable(): Promise<LecapsTableItem[]> {
  const r = await fetch("/api/lecaps-table", { method: "GET" })
  if (!r.ok) throw new Error(`LECAPs table error: ${r.status}`)
  const data = (await r.json()) as Partial<LecapsTableResponse>

  if (!data.items || !Array.isArray(data.items)) {
    throw new Error("LECAPs table inválida (no es array)")
  }
  return data.items
}
