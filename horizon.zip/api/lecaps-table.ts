// api/lecaps-table.ts
import type { VercelRequest, VercelResponse } from "@vercel/node";
import chromium from "@sparticuz/chromium";
import puppeteer, { type Browser } from "puppeteer-core";

const PAGE_URL = "https://www.acuantoesta.com.ar/lecaps";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  // cache 20 min en CDN (Vercel)
  res.setHeader("Cache-Control", "s-maxage=1200, stale-while-revalidate=1200");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "GET")
    return res.status(405).json({ error: "Method not allowed" });

  let browser: Browser | null = null;

  try {
    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath:
        process.env.PUPPETEER_EXECUTABLE_PATH ?? (await chromium.executablePath()),
      headless: true, // ✅ FIX: no usar chromium.headless (Typescript rompe en algunas versiones)
      defaultViewport: { width: 1365, height: 768 },
    });

    const page = await browser.newPage();
    await page.setUserAgent(
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
    );

    await page.goto(PAGE_URL, { waitUntil: "networkidle2", timeout: 45_000 });
    await page.waitForSelector("table", { timeout: 25_000 });

    const data = await page.evaluate(() => {
      const norm = (s: string) => s.replace(/\s+/g, " ").trim();

      const table = document.querySelector("table");
      if (!table) return { headers: [], rows: [] as string[][] };

      const headers = Array.from(table.querySelectorAll("thead th")).map((th) =>
        norm(th.textContent || "")
      );

      const rows = Array.from(table.querySelectorAll("tbody tr")).map((tr) => {
        const cells = Array.from(tr.querySelectorAll("td")).map((td) =>
          norm(td.textContent || "")
        );
        return cells;
      });

      return { headers, rows };
    });

    const headers = (data.headers || []).map((h, i) => h || `col_${i}`);

    const items = (data.rows || []).map((cells) => {
      const obj: Record<string, string> = {};
      headers.forEach((h, i) => {
        obj[h] = cells[i] ?? "";
      });

      // primer celda suele traer el ticker (a veces con "LECAP" abajo)
      const first = cells[0] ?? "";
      const ticker = first.split(" ")[0].trim();
      obj["_ticker"] = ticker;

      return obj;
    });

    return res.status(200).json({
      fetchedAt: new Date().toISOString(),
      source: PAGE_URL,
      headers,
      items,
    });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message ?? "Scrape failed" });
  } finally {
    try {
      if (browser) await browser.close();
    } catch {}
  }
}
