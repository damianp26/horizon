import type { VercelRequest, VercelResponse } from "@vercel/node"

const BYMA_URL =
  "https://open.bymadata.com.ar/vanoms-be-core/rest/api/bymadata/free/cauciones"

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS (por si accedés desde otro dominio o preview)
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Methods", "POST,OPTIONS")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type")

  if (req.method === "OPTIONS") return res.status(204).end()
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" })

  try {
    const payload =
      typeof req.body === "string" ? JSON.parse(req.body) : (req.body ?? {})
    const upstream = await fetch(BYMA_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // headers similares a tu python (no siempre necesarios, pero ayudan)
        Origin: "https://open.bymadata.com.ar",
        Referer: "https://open.bymadata.com.ar/",
        "User-Agent": "horizon/1.0",
      },
      body: JSON.stringify(payload),
    })

    if (!upstream.ok) {
      const text = await upstream.text()
      return res.status(upstream.status).send(text)
    }

    const data = await upstream.json()
    return res.status(200).json(data)
  } catch (e: any) {
    return res.status(500).json({ error: e?.message ?? "Unknown error" })
  }
}
