import path from "path"
import react from "@vitejs/plugin-react"
import tailwindcss from "@tailwindcss/vite"
import { defineConfig } from "vite"

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    proxy: {
      "/api/cauciones": {
        target: "https://open.bymadata.com.ar",
        changeOrigin: true,
        secure: false, // solo dev (por tu certificado)
        rewrite: () => "/vanoms-be-core/rest/api/bymadata/free/cauciones",
      },

      "/api/dolar": {
        target: "https://dolarapi.com",
        changeOrigin: true,
        secure: true,
        rewrite: () => "/v1/dolares/oficial",
      },

      "/api/lecaps": {
        target: "https://www.acuantoesta.com.ar",
        changeOrigin: true,
        secure: true,
        rewrite: () => "/api/lecaps-prices",
      },

    },
  }
})
